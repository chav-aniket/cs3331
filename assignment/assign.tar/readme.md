# CS3331 Assignment 1
## Implementation of Peer-to-Peer Network using Distributed Hash Table
Aniket Chavan (z5265106)

init_python.sh can be run using ```sh init_python.sh```
join.sh has been added alongside this as a way of adding a peer and can be used as ```sh join.sh```
